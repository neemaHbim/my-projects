
package e.warett.application;

/**
 *
 * @author Neema
 */
public class EWarettApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
