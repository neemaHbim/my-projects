/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wallet.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import wallet.model.WalletModel;
import wallet.utilities.HibernateUtil;

/**
 *
 * @author Aimable
 */
public class AccountDao {
         Session ss = null;
    Transaction tx = null;
    
      public void saveAccount(WalletModel ex){
        try {
            ss = HibernateUtil.getSessionFactory().openSession();
            tx = ss.beginTransaction();
            ss.save(ex);
            tx.commit();
            ss.close();
        } catch (Exception e) {
        }
    }
}
