/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wallet.model;

import java.util.Scanner;

/**
 *
 * @author Neema
 *
 */
public class EWalletSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         EwalletAccount obj1=new EwalletAccount("Neema","22719");
         obj1.showMenu();
    }
    
}



class EwalletAccount {
 

int balance;
int previousTransaction;
String Username;
String Userid;
 
EwalletAccount(String Uname,String Uid)
{
Username=Uname;
Userid=Uid;

}

void deposit(int amount)
{
if (amount !=0)
{
  balance=balance +1000+amount;
previousTransaction=amount+1000;

}
}

void withdraw(int amount){
if (amount !=0)
{
balance=balance+1000-amount;
previousTransaction=-amount+1000;

}
}
void getPreviousTransaction ()
{

if(previousTransaction > 0)
{
System.out.println("Deposited:" +previousTransaction);
}
else if(previousTransaction<0)
{
System.out.println("withdraw:"  +Math.abs(previousTransaction));
}
else
{
System.out.println("No transaction occured");

}
}
 void showMenu()
 {
 char option='\0';
 Scanner scanner= new Scanner(System.in);
 
 System.out.println( "welcome" +Username );
  System.out.println("your id is" +Userid);
   System.out.println("\n");
    System.out.println("1.check balance");
     System.out.println("2.deposit");
      System.out.println("3.withdraw");
       System.out.println("4.previous transaction");
        System.out.println("5.Exit");
        
        do
        {
             System.out.println("================================");
              System.out.println("Enter an option");
               System.out.println("===============================");
                option =scanner.next().charAt(0);
                System.out.println("\n");
                
                
                switch(option)
                {
                    case '1':
                        
                         System.out.println("===================");
                         System.out.println("Balance =" +balance);
                         System.out.println("===================");
                         System.out.println("\n");
                         break;
                  
                         
                         case '2':
                        
                         System.out.println("===========================");
                         System.out.println("Enter an amount to deposit:");
                         System.out.println("============================");
                         int amount =scanner.nextInt();
                         deposit (amount);
                         System.out.println("\n");
                         break;
                           case '3':
                        
                         System.out.println("==============================");
                         System.out.println("Enter an amount to withdraw:");
                         System.out.println("==============================");
                         int amount2 =scanner.nextInt();
                         withdraw (amount2);
                         System.out.println("\n");
                         break;
                         
                         case '4':
                        
                         System.out.println("===================");
                         getPreviousTransaction();
                         System.out.println("===================");
                         System.out.println("\n");
                         break;
                         case '5':
                             System.out.println("***************************");
                                break; 
                         default:
                             System.out.println("failed.try again");
                             break;
                }
                        }  while(option != '5');                

       System.out.println("thank you for using our services");
 }}
                        