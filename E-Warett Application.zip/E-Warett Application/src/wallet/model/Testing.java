
package wallet.model;

import wallet.utilities.HibernateUtil;

/**
 *
 * @author Neema
 */
public class Testing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//          HibernateUtil uti = new HibernateUtil();
//        uti.getSessionFactory();
    }
    
}
