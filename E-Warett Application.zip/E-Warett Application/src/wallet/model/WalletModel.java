
package wallet.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Neema
 */
@Entity
public class WalletModel {
    @Id
    private String fullNames;
    private String phoneNumber;
    private Integer age;
    private String Gender;
    private String martialStatus;
    private String job;

    public WalletModel() {
    }

    public WalletModel(String fullNames, String phoneNumber, Integer age, String Gender, String martialStatus, String job) {
        this.fullNames = fullNames;
        this.phoneNumber = phoneNumber;
        this.age = age;
        this.Gender = Gender;
        this.martialStatus = martialStatus;
        this.job = job;
    }

    public String getFullNames() {
        return fullNames;
    }

    public void setFullNames(String fullNames) {
        this.fullNames = fullNames;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getMartialStatus() {
        return martialStatus;
    }

    public void setMartialStatus(String martialStatus) {
        this.martialStatus = martialStatus;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    
    
}